package com.example.tunein

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
